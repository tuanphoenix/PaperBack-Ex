# Vietnamese Extensions
Vietnamese sources for [Paperback](https://paperback.moe/)

## Link extension
```
https://JustaTama.github.io/Paperback-Extensions-VN/
```
## Cách add extensions vào Paperback
[Nhấn vào đây để add extensions](https://paperback.moe/addRepo/?name=Vietnamese%20Extensions%20created%20by%20JustaTama&url=https%3A%2F%2FJustaTama.github.io%2FPaperback-Extensions-VN%2F).
Khi nhấn vào sẽ tự chuyển tiếp qua ứng dụng Paperback.
## Sources

|STT    | Name                      | Source URL                                 |
| ----- | ------------------------- | ------------------------------------------ |
|   1   | BaoTangTruyen             | https://baotangtruyen4.com                 |
|   2   | Blogtruyen                | https://blogtruyen.vn                      |
|   3   | DocTruyen3Q               | https://doctruyen3qmax.com                 |
|   4   | HentaiVip                 | https://hentaivnmoi.net                    |
|   5   | HentaiVN                  | https://hentaivn.autos                     |
|   6   | LxManga                   | https://lxmanga.net                        |
|   7   | Nettruyen                 | https://www.nettruyenus.com                |
|   8   | Nhattruyen                | https://nhattruyenplus.com                 |
|   9   | SayHentai                 | https://sayhentai.fun                      |
|   10  | TruyentranhLH             | https://truyentranhlh.net                  |
|   11  | TruyenVN                  | https://truyenvnhay.com                    |
|   12  | Yurineko                  | https://yurineko.net                       |